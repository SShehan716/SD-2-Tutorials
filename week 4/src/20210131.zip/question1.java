public class question1 {
    public static void main(String[] args){
        int count = 0;
        do{
            System.out.println(" Hello ");
            count = count + 1;

        } while (count < 9);
    }
}
